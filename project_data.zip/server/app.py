from flask import Flask, jsonify
from flask_socketio import SocketIO
from flask import request

app = Flask(__name__)
socketio = SocketIO(app)

routes = {
'route1': {
    'points': [
        {'latitude': 8.5241, 'longitude': 76.9366},  # Trivandrum
        {'latitude': 8.7746, 'longitude': 76.7870},  # Neyyattinkara
        {'latitude': 8.5773, 'longitude': 76.8777},  # Parassala
        {'latitude': 8.5029, 'longitude': 76.8991},  # Maranalloor
        {'latitude': 8.4837, 'longitude': 76.9571},  # Kilimanoor
        {'latitude': 8.5093, 'longitude': 77.0577},  # Attingal
        {'latitude': 8.7301, 'longitude': 77.0882},  # Varkala
        {'latitude': 8.8874, 'longitude': 76.6220},  # Kottarakkara
        {'latitude': 9.0168, 'longitude': 76.5757},  # Adoor
        {'latitude': 9.0905, 'longitude': 76.5476},  # Pandalam
        {'latitude': 9.3369, 'longitude': 76.5692},  # Haripad
        {'latitude': 9.4908, 'longitude': 76.3268},  # Kayamkulam
        {'latitude': 9.4834, 'longitude': 76.4120},  # Mavelikkara
        {'latitude': 9.3177, 'longitude': 76.3473},  # Chengannur
        {'latitude': 9.3250, 'longitude': 76.4570},  # Thiruvalla
        {'latitude': 9.3067, 'longitude': 76.5705},  # Changanassery
        {'latitude': 9.2335, 'longitude': 76.7145},  # Kottayam
        {'latitude': 9.3746, 'longitude': 76.5740},  # Vaikom
        {'latitude': 9.5049, 'longitude': 76.3278},  # Cherthala
        {'latitude': 9.4900, 'longitude': 76.3311},  # Alappuzha
    ],
    'traffic': 0.2
}
,
'route2': {
    'points': [
        {'latitude': 8.5241, 'longitude': 76.9366},  # Trivandrum
        {'latitude': 8.4865, 'longitude': 76.9492},  # Thiruvananthapuram International Airport
        {'latitude': 8.4583, 'longitude': 76.9224},  # Veli Tourist Village
        {'latitude': 8.4924, 'longitude': 76.9648},  # Technopark
        {'latitude': 8.5653, 'longitude': 76.8607},  # Kovalam
        {'latitude': 8.6670, 'longitude': 76.8537},  # Vizhinjam
        {'latitude': 8.7773, 'longitude': 76.8710},  # Poovar
        {'latitude': 8.9127, 'longitude': 76.6233},  # Kottarakkara
        {'latitude': 9.0018, 'longitude': 76.5291},  # Pathanamthitta
        {'latitude': 9.1094, 'longitude': 76.5344},  # Adoor
        {'latitude': 9.1791, 'longitude': 76.5687},  # Pandalam
        {'latitude': 9.3035, 'longitude': 76.5611},  # Changanassery
        {'latitude': 9.3527, 'longitude': 76.5022},  # Kottayam
        {'latitude': 9.4132, 'longitude': 76.4185},  # Vaikom
        {'latitude': 9.4567, 'longitude': 76.3661},  # Kumarakom
        {'latitude': 9.4951, 'longitude': 76.3261},  # Alleppey
        {'latitude': 9.4900, 'longitude': 76.3311},  # Alappuzha
    ],
    'traffic': 0.4
}
,
'route3': {
    'points': [
        {'latitude': 8.5241, 'longitude': 76.9366},  # Trivandrum
        {'latitude': 8.7202, 'longitude': 76.7217},  # Nedumangad
        {'latitude': 8.9031, 'longitude': 76.6320},  # Kottarakkara
        {'latitude': 8.9967, 'longitude': 76.5138},  # Adoor
        {'latitude': 9.0977, 'longitude': 76.4995},  # Pandalam
        {'latitude': 9.2051, 'longitude': 76.5186},  # Chengannur
        {'latitude': 9.3421, 'longitude': 76.5061},  # Thiruvalla
        {'latitude': 9.3936, 'longitude': 76.4240},  # Changanassery
        {'latitude': 9.4613, 'longitude': 76.3491},  # Vaikom
        {'latitude': 9.5554, 'longitude': 76.3185},  # Alappuzha
    ],
    'traffic': 0.6
}
}


def suggest_best_route():
    return min(routes, key=lambda x: routes[x]['traffic'])


@app.route('/update_traffic', methods=['POST'])
def update_traffic_route():
    route_name = request.json.get('route_name') 
    new_traffic = request.json.get('traffic') 
    if route_name in routes and 0 <= new_traffic <= 1:
        routes[route_name]['traffic'] = new_traffic
        return jsonify({'message': 'Traffic data updated successfully for route: {}'.format(route_name)})
    else:
        return jsonify({'error': 'Route not found or invalid traffic value'}), 400


@app.route('/best_route')
def best_route():
    best_route = suggest_best_route()
    print("\n\x1b[35m===========================================")
    print("      Checking for best route")
    print("===========================================\x1b[0m")
    return jsonify({'best_route': best_route})

@app.route('/routes')
def all_routes():
    return jsonify(routes)
if __name__ == '__main__':
    print("\n\x1b[35m===========================================")
    print("      Welcome to Smart Route Finder")
    print("===========================================\x1b[0m")
    print("\x1b[32mServer is running...\x1b[0m")

    app.run(debug=True, host='0.0.0.0')
    socketio.run(app, debug=True, host='0.0.0.0')
