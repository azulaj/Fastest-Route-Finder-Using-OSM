import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_osm_plugin/flutter_osm_plugin.dart';
import 'package:routefinder/constants.dart';
import 'package:http/http.dart' as http;

class PlotMap extends StatefulWidget {
  const PlotMap({super.key});

  @override
  _PlotMapState createState() => _PlotMapState();
}

class _PlotMapState extends State<PlotMap> with OSMMixinObserver {
  late MapController mapController;
  bool isMapReady = false;
  String bestRouteX = '';
  late Timer _timer;

  void startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 10), (Timer timer) {
      checkBestRoute();
    });
  }

  void stopTimer() {
    if (_timer.isActive) {
      _timer.cancel();
    }
  }

  @override
  void initState() {
    super.initState();
    mapController = MapController(
      initPosition: GeoPoint(
        latitude: 8.5241,
        longitude: 76.9366,
      ),
    );
    mapController.addObserver(this);
    startTimer();
  }

  void _showServerIPDialog(BuildContext context) {
    String newServerIP = '';

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Set Server IP"),
          content: TextField(
            decoration: const InputDecoration(hintText: "Enter Server IP"),
            onChanged: (value) {
              newServerIP = value;
            },
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text("Cancel"),
            ),
            TextButton(
              onPressed: () {
                print("New Server IP: $newServerIP");
                serverIP = newServerIP.trim();
                Navigator.of(context).pop();
              },
              child: const Text("Save"),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () {
              _showServerIPDialog(context);
            },
          ),
        ],
        centerTitle: true,
        title: const Text("Smart Route Finder"),
      ),
      body: Stack(
        children: [
          OSMFlutter(
            controller: mapController,
            osmOption: OSMOption(
              userTrackingOption: const UserTrackingOption(
                enableTracking: false,
                unFollowUser: false,
              ),
              zoomOption: const ZoomOption(
                initZoom: 13,
                minZoomLevel: 10,
                maxZoomLevel: 19,
                stepZoom: 1.0,
              ),
              userLocationMarker: UserLocationMaker(
                personMarker: const MarkerIcon(
                  icon: Icon(
                    Icons.location_history_rounded,
                    color: Colors.red,
                    size: 48,
                  ),
                ),
                directionArrowMarker: const MarkerIcon(
                  icon: Icon(
                    Icons.double_arrow,
                    size: 48,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Future<void> mapIsReady(bool isReady) async {
    setState(() {
      isMapReady = isReady;
    });
    if (isReady) {
      plotRoute();
    }
  }

  List<Map<String, double>> route1 = [
    {'latitude': 8.5241, 'longitude': 76.9366},
    {'latitude': 8.7746, 'longitude': 76.7870},
    {'latitude': 8.5773, 'longitude': 76.8777},
    {'latitude': 8.5029, 'longitude': 76.8991},
    {'latitude': 8.4837, 'longitude': 76.9571},
    {'latitude': 8.5093, 'longitude': 77.0577},
    {'latitude': 8.7301, 'longitude': 77.0882},
    {'latitude': 8.8874, 'longitude': 76.6220},
    {'latitude': 9.0168, 'longitude': 76.5757},
    {'latitude': 9.0905, 'longitude': 76.5476},
    {'latitude': 9.3369, 'longitude': 76.5692},
    {'latitude': 9.4908, 'longitude': 76.3268},
    {'latitude': 9.4834, 'longitude': 76.4120},
    {'latitude': 9.3177, 'longitude': 76.3473},
    {'latitude': 9.3250, 'longitude': 76.4570},
    {'latitude': 9.3067, 'longitude': 76.5705},
    {'latitude': 9.2335, 'longitude': 76.7145},
    {'latitude': 9.3746, 'longitude': 76.5740},
    {'latitude': 9.5049, 'longitude': 76.3278},
    {'latitude': 9.4900, 'longitude': 76.3311},
  ];

  List<Map<String, double>> route2 = [
    {'latitude': 8.5241, 'longitude': 76.9366},
    {'latitude': 8.4865, 'longitude': 76.9492},
    {'latitude': 8.4583, 'longitude': 76.9224},
    {'latitude': 8.4924, 'longitude': 76.9648},
    {'latitude': 8.5653, 'longitude': 76.8607},
    {'latitude': 8.6670, 'longitude': 76.8537},
    {'latitude': 8.7773, 'longitude': 76.8710},
    {'latitude': 8.9127, 'longitude': 76.6233},
    {'latitude': 9.0018, 'longitude': 76.5291},
    {'latitude': 9.1094, 'longitude': 76.5344},
    {'latitude': 9.1791, 'longitude': 76.5687},
    {'latitude': 9.3035, 'longitude': 76.5611},
    {'latitude': 9.3527, 'longitude': 76.5022},
    {'latitude': 9.4132, 'longitude': 76.4185},
    {'latitude': 9.4567, 'longitude': 76.3661},
    {'latitude': 9.4951, 'longitude': 76.3261},
    {'latitude': 9.4900, 'longitude': 76.3311},
  ];
  List<Map<String, double>> route3 = [
    {'latitude': 8.5241, 'longitude': 76.9366},
    {'latitude': 8.7202, 'longitude': 76.7217},
    {'latitude': 8.9031, 'longitude': 76.6320},
    {'latitude': 8.9967, 'longitude': 76.5138},
    {'latitude': 9.0977, 'longitude': 76.4995},
    {'latitude': 9.2051, 'longitude': 76.5186},
    {'latitude': 9.3421, 'longitude': 76.5061},
    {'latitude': 9.3936, 'longitude': 76.4240},
    {'latitude': 9.4613, 'longitude': 76.3491},
    {'latitude': 9.5554, 'longitude': 76.3185},
  ];

  List<Map<String, double>> points = [
    {'latitude': 8.5241, 'longitude': 76.9366}, // Trivandrum
    {'latitude': 8.7202, 'longitude': 76.7217}, // Nedumangad
    {'latitude': 8.9031, 'longitude': 76.6320}, // Kottarakkara
    {'latitude': 8.9967, 'longitude': 76.5138}, // Adoor
    {'latitude': 9.0977, 'longitude': 76.4995}, // Pandalam
    {'latitude': 9.2051, 'longitude': 76.5186}, // Chengannur
    {'latitude': 9.3421, 'longitude': 76.5061}, // Thiruvalla
    {'latitude': 9.3936, 'longitude': 76.4240}, // Changanassery
    {'latitude': 9.4613, 'longitude': 76.3491}, // Vaikom
    {'latitude': 9.5554, 'longitude': 76.3185}, // Alappuzha
  ];

  Future<void> plotRoute() async {
    // Fetch the best route from the backend
    final response =
        await http.get(Uri.parse('http://$serverIP:5000/best_route'));

    if (response.statusCode == 200) {
      final Map<String, dynamic> data = json.decode(response.body);
      String bestRoute = data['best_route'];
      bestRouteX = bestRoute;

      if (bestRoute == 'route1') {
        print('The best route is route1');
        points = route1;
      } else if (bestRoute == 'route2') {
        print('The best route is route2');
        points = route2;
      } else if (bestRoute == 'route3') {
        print('The best route is route3');
        points = route3;
      } else {
        print('Unknown best route: $bestRoute');
      }
    }

    for (int i = 0; i < points.length - 1; i++) {
      await mapController.drawRoad(
        GeoPoint(
          latitude: points[i]['latitude']!,
          longitude: points[i]['longitude']!,
        ),
        GeoPoint(
          latitude: points[i + 1]['latitude']!,
          longitude: points[i + 1]['longitude']!,
        ),
        roadType: RoadType.car,
        roadOption: const RoadOption(
          roadColor: Colors.red,
          roadWidth: 5,
        ),
      );
    }
  }

  

  @override
  void dispose() {
    mapController.removeObserver(this);
    super.dispose();
    stopTimer();
  }

  Future<void> checkBestRoute() async {
    final response =
        await http.get(Uri.parse('http://$serverIP:5000/best_route'));

    if (response.statusCode == 200) {
      final Map<String, dynamic> data = json.decode(response.body);

      String bestRoute = data['best_route'];

      if (bestRouteX != bestRoute) {
        plotRoute();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: Colors.yellow,
            content: Text('New shortest route found: $bestRoute'),
          ),
        );
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: Colors.green,
            content: Text('Changing to $bestRoute'),
          ),
        );

        bestRouteX = bestRoute;

        if (bestRoute == 'route1') {
          print('The best route is route1');
          points = route1;
        } else if (bestRoute == 'route2') {
          print('The best route is route2');
          points = route2;
        } else if (bestRoute == 'route3') {
          print('The best route is route3');
          points = route3;
        } else {
          print('Unknown best route: $bestRoute');
        }
      }
    }
  }
}
