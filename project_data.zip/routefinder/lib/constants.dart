import 'package:flutter/material.dart';

Color defaultPropertyBackgroundColour = Colors.red;
Color defaultPropertyForegroundColour = Colors.orange;


String serverIP = '192.168.1.8';