package com.example.routefinder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
